/**
 * Webify Multi-Device Anti-Ban Queue Dispatcher (Up to 6 Devices)
 * 
 * Rules:
 * 1. 50 Verified Leads Max per 24 hours PER DEVICE (3 Devices = 150 leads/day, 6 Devices = 300/day)
 * 2. Atomic queue claiming ensures NO two devices ever message or touch the same lead
 * 3. 1 message every 1 to 2 minutes random jitter (60s - 120s) per device
 * 4. Micro-batches of 5 to 8 messages -> followed by random 50 to 80 minute human tea breaks
 * 5. Two-Step Conversational Shield: respectful founder check (zero links, zero spam report risk)
 * 6. Supports Global Business Numbers: USA (+1), UK (+44), Canada (+1), Australia (+61), India (+91)
 */

const path = require('path');
const fs = require('fs');
const ai = require('./ai');
const scraper = require('./scraper');
const whatsapp = require('./whatsapp');

const MAX_DEVICES = parseInt(process.env.MAX_DEVICES || '6', 10);
const CONFIG_FILE = path.join(__dirname, 'bot_config.json');

// Persistent & Customizable 24-Hour Limits & Pacing Config
function loadBotConfig() {
  const defaults = {
    dailyMaxLeadsPerDevice: parseInt(process.env.DAILY_MAX_LEADS_PER_DEVICE || '50', 10),
    minMsgDelayMs: parseInt(process.env.MIN_MSG_DELAY_MS || '60000', 10),
    maxMsgDelayMs: parseInt(process.env.MAX_MSG_DELAY_MS || '120000', 10),
    minBreakMins: parseInt(process.env.MIN_BREAK_MINS || '50', 10),
    maxBreakMins: parseInt(process.env.MAX_BREAK_MINS || '80', 10),
    specialDeviceNumber: '9416085989',
    specialDailyLimit: 10,
    vaultCode: '3369',
    pacingPreset: 'balanced' // 'ultra_safe', 'balanced', 'high_growth', 'custom'
  };

  try {
    if (fs.existsSync(CONFIG_FILE)) {
      const data = JSON.parse(fs.readFileSync(CONFIG_FILE, 'utf-8'));
      return { ...defaults, ...data };
    }
  } catch (err) {
    console.warn('Notice: using default bot config:', err.message);
  }
  return defaults;
}

let botConfig = loadBotConfig();

function saveBotConfig(updates) {
  botConfig = { ...botConfig, ...updates };
  try {
    fs.writeFileSync(CONFIG_FILE, JSON.stringify(botConfig, null, 2), 'utf-8');
    console.log(`⚙️ [Config Saved] 24-Hour limit updated to: ${botConfig.dailyMaxLeadsPerDevice} msgs/device (Preset: ${botConfig.pacingPreset || 'custom'}).`);
  } catch (err) {
    console.error('Failed to save bot_config.json:', err.message);
  }
  return botConfig;
}

function getDailyMaxLeadsPerDevice() {
  return botConfig.dailyMaxLeadsPerDevice || 50;
}

function getDailyLimitForDevice(deviceId) {
  const session = whatsapp.getDevice(deviceId);
  const phone = session && session.phone ? String(session.phone).replace(/\D/g, '') : '';

  // Special Rule: 9416085989 is STRICTLY capped at 10 msgs/day!
  if (phone.includes('9416085989') || (session && session.sock?.user?.id && String(session.sock.user.id).includes('9416085989'))) {
    return 10;
  }

  // Check per-device custom override in botConfig
  if (botConfig.deviceLimits && botConfig.deviceLimits[String(deviceId)]) {
    return parseInt(botConfig.deviceLimits[String(deviceId)], 10) || getDailyMaxLeadsPerDevice();
  }

  return getDailyMaxLeadsPerDevice();
}

function setDailyMaxLeadsPerDevice(count, preset = 'custom') {
  const num = parseInt(count, 10);
  if (isNaN(num) || num < 1) return botConfig;

  const updates = { dailyMaxLeadsPerDevice: num, pacingPreset: preset };

  // Adjust pacing intelligently if presets are chosen
  if (preset === 'ultra_safe' || num <= 30) {
    updates.minMsgDelayMs = 90000;
    updates.maxMsgDelayMs = 180000;
    updates.minBreakMins = 60;
    updates.maxBreakMins = 90;
  } else if (preset === 'high_growth' || num >= 100) {
    updates.minMsgDelayMs = 45000;
    updates.maxMsgDelayMs = 90000;
    updates.minBreakMins = 35;
    updates.maxBreakMins = 55;
  } else if (preset === 'balanced') {
    updates.minMsgDelayMs = 60000;
    updates.maxMsgDelayMs = 120000;
    updates.minBreakMins = 50;
    updates.maxBreakMins = 80;
  }

  return saveBotConfig(updates);
}

function getBotConfig() {
  return { ...botConfig };
}

const MIN_BATCH_SIZE = parseInt(process.env.MIN_BATCH_SIZE || '5', 10);
const MAX_BATCH_SIZE = parseInt(process.env.MAX_BATCH_SIZE || '8', 10);
const STRICT_HOURS = process.env.STRICT_HOURS === 'true';

let isRunning = false;
let isPaused = false;
let isProactiveScraping = false;
let currentDay = new Date().toDateString();

// Device worker states: deviceId (1..6) -> WorkerState
const deviceStates = new Map();

function getRandomBatchLimit() {
  return Math.floor(MIN_BATCH_SIZE + Math.random() * (MAX_BATCH_SIZE - MIN_BATCH_SIZE + 1));
}

function getRandomMsgDelayMs() {
  const min = botConfig.minMsgDelayMs || 60000;
  const max = botConfig.maxMsgDelayMs || 120000;
  return Math.floor(min + Math.random() * (max - min + 1));
}

function getRandomBreakDurationMs() {
  const minMins = botConfig.minBreakMins || 50;
  const maxMins = botConfig.maxBreakMins || 80;
  const mins = minMins + Math.random() * (maxMins - minMins);
  return Math.floor(mins * 60 * 1000);
}

function isOperatingHours() {
  if (!STRICT_HOURS) return true;
  const now = new Date();
  const hour = now.getHours();
  return (hour >= 9 && hour < 22);
}

function formatLocalTime(timestamp) {
  if (!timestamp) return null;
  try {
    return new Date(timestamp).toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      hour12: true
    });
  } catch (e) {
    return new Date(timestamp).toLocaleTimeString();
  }
}

function checkAndResetDailyCounters() {
  const todayStr = new Date().toDateString();
  if (todayStr !== currentDay) {
    currentDay = todayStr;
    for (const state of deviceStates.values()) {
      state.dailySentCount = 0;
      state.currentBatchCount = 0;
      state.currentBatchLimit = getRandomBatchLimit();
    }
    console.log(`🌅 [Anti-Ban Engine] New calendar day. Reset daily outreach counters to 0/${getDailyMaxLeadsPerDevice()} per device.`);
  }
}

function getOrCreateDeviceState(deviceId) {
  let state = deviceStates.get(deviceId);
  if (!state) {
    state = {
      id: deviceId,
      currentBatchCount: 0,
      currentBatchLimit: getRandomBatchLimit(),
      dailySentCount: 0,
      totalSentSession: 0,
      consecutiveFailures: 0,
      nextActionTime: null,
      currentStatus: 'Initializing slot...'
    };
    deviceStates.set(deviceId, state);
  }
  return state;
}

async function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Worker loop for an individual WhatsApp device slot
 */
async function runDeviceWorker(deviceId) {
  const state = getOrCreateDeviceState(deviceId);
  console.log(`⚡ [Worker Device ${deviceId}] Started independent dispatcher (50 leads/day cap).`);

  // Stagger startup so all devices don't fire at the exact same second
  await sleep((deviceId - 1) * 12000);

  while (isRunning) {
    if (isPaused) {
      state.currentStatus = 'Paused by User';
      await sleep(5000);
      continue;
    }

    checkAndResetDailyCounters();

    // 1. Device Daily Cap Check (Special 10 msgs/day for 9416085989; customizable for all others)
    const currentDailyLimit = getDailyLimitForDevice(deviceId);
    if (state.dailySentCount >= currentDailyLimit) {
      const isSpecial = currentDailyLimit === 10;
      state.currentStatus = `Daily Safety Cap Reached (${state.dailySentCount}/${currentDailyLimit}${isSpecial ? ' [Locked @ 10/day]' : ''}). Resting safely until tomorrow...`;
      state.nextActionTime = Date.now() + 60 * 60 * 1000;
      await sleep(30000); // Check every 30s so user raising limit in UI resumes bot immediately
      continue;
    }

    // 2. Strict Operating Hours Check (if enabled)
    if (!isOperatingHours()) {
      state.currentStatus = '🌙 Night Rest Mode. Resuming during business hours (9 AM)...';
      state.nextActionTime = Date.now() + 30 * 60 * 1000;
      await sleep(60000);
      continue;
    }

    // 3. Check if this specific device is connected
    if (!whatsapp.isDeviceConnected(deviceId)) {
      state.currentStatus = `Waiting for WhatsApp QR scan on /qr?device=${deviceId}...`;
      await sleep(8000);
      continue;
    }

    // 4. Proactive lead harvest if backlog for this device territory is low
    const remainingInQueue = scraper.getQueuedLeadsCount(deviceId);
    if (remainingInQueue < 15 && !isProactiveScraping) {
      isProactiveScraping = true;
      console.log(`⚡ [Scraper] Device ${deviceId} queue has ${remainingInQueue} leads. Harvesting fresh leads in background...`);
      scraper.triggerFreeWebScraper({ targetAccount: `device_${deviceId}`, targetCount: 25 })
        .catch(e => console.error('Continuous harvest notice:', e.message))
        .finally(() => { isProactiveScraping = false; });
    }

    // 5. Atomic Claim: Grab next unassigned lead for this device
    let lead = scraper.claimNextLead(deviceId);
    if (!lead) {
      state.currentStatus = `Queue Empty: Harvesting fresh leads for Device ${deviceId}...`;
      try {
        await scraper.triggerFreeWebScraper({ targetAccount: `device_${deviceId}`, targetCount: 25 });
      } catch (err) {}
      lead = scraper.claimNextLead(deviceId);
      if (!lead) {
        await sleep(15000);
        continue;
      }
    }

    // 6. Validate & Format Phone Number
    if (String(lead.phone).startsWith('91') || lead.country === 'India') {
      console.log(`🛡️ [Safety Shield] Dropped Indian number +${lead.phone}. Webify bot strictly targets US/UK/Canada/Australia.`);
      scraper.updateLeadStatus(lead.phone, 'rejected_indian_number', null, deviceId);
      continue;
    }

    const formatted = scraper.formatWhatsAppJid(lead.phone);
    if (!formatted) {
      console.log(`❌ [Device ${deviceId}] Skipped invalid phone ${lead.phone}.`);
      scraper.updateLeadStatus(lead.phone, 'invalid_number', null, deviceId);
      continue;
    }

    lead.jid = formatted.jid;
    lead.phone = formatted.cleanNumber;

    // 7. Duplicate & Sent Shield
    if (scraper.isPhoneAlreadySent(lead.phone) || whatsapp.hasExistingChat(lead.phone)) {
      console.log(`⏩ [Device ${deviceId}] ${lead.phone} was already contacted. Skipping!`);
      scraper.updateLeadStatus(lead.phone, 'sent', null, deviceId);
      continue;
    }

    // 8. Verify WhatsApp registration
    state.currentStatus = `Checking WhatsApp registration for +${lead.phone}...`;
    const waCheck = await whatsapp.checkNumberOnWhatsApp(deviceId, lead.phone);
    if (!waCheck.exists) {
      console.log(`❌ [Device ${deviceId}] +${lead.phone} is not registered on WhatsApp. Skipping!`);
      scraper.updateLeadStatus(lead.phone, 'not_on_whatsapp', null, deviceId);
      await sleep(300);
      continue;
    }

    lead.jid = waCheck.jid || formatted.jid;

    // 9. Generate Two-Step Undetectable Outreach Message
    state.currentStatus = `Preparing personalized outreach for +${lead.phone}...`;
    const outreachText = await ai.generateOutreachMessage(lead);

    // 10. Send via WhatsApp through this device
    state.currentStatus = `Sending outreach to +${lead.phone}...`;
    let sendSucceeded = false;
    try {
      const sent = await whatsapp.sendTextMessage(deviceId, lead.jid, outreachText);
      if (sent) {
        scraper.updateLeadStatus(lead.phone, 'sent', null, deviceId);
        state.currentBatchCount++;
        state.totalSentSession++;
        state.dailySentCount++;
        state.consecutiveFailures = 0;
        sendSucceeded = true;
        console.log(`✅ [Real WhatsApp Sent by Device ${deviceId} (${state.currentBatchCount}/${state.currentBatchLimit})] To +${lead.phone}. Today: ${state.dailySentCount}/${getDailyMaxLeadsPerDevice()}`);
      } else {
        state.consecutiveFailures++;
        scraper.updateLeadStatus(lead.phone, 'failed', 'Socket send failure', deviceId);
      }
    } catch (sendErr) {
      state.consecutiveFailures++;
      console.error(`❌ [Device ${deviceId} Send Error]:`, sendErr.message);
      scraper.updateLeadStatus(lead.phone, 'failed', sendErr.message, deviceId);
    }

    // Circuit Breaker: 3 consecutive failures cools down this device socket for 20 mins
    if (state.consecutiveFailures >= 3) {
      state.currentStatus = '⚠️ Circuit Breaker engaged (3 delivery hiccups). Cooling down socket for 20 mins...';
      state.nextActionTime = Date.now() + 20 * 60 * 1000;
      console.log(`\n🛡️ [Circuit Breaker Device ${deviceId}] 3 hiccups detected. Cooling down for 20 mins until ${formatLocalTime(state.nextActionTime)}...\n`);
      await sleep(20 * 60 * 1000);
      state.consecutiveFailures = 0;
      continue;
    }

    // 11. Human Pacing / Breaks
    if (sendSucceeded) {
      if (state.currentBatchCount >= state.currentBatchLimit) {
        const breakMs = getRandomBreakDurationMs();
        const breakMins = Math.round(breakMs / 60000);
        state.nextActionTime = Date.now() + breakMs;
        state.currentStatus = `Mini-batch of ${state.currentBatchLimit} sent! Taking ${breakMins}-min tea break...`;
        console.log(`\n☕ [Human Break Device ${deviceId}] Batch limit hit (${state.currentBatchLimit} sent). Taking ${breakMins}-minute break until ${formatLocalTime(state.nextActionTime)}...\n`);

        await sleep(breakMs);

        state.currentBatchCount = 0;
        state.currentBatchLimit = getRandomBatchLimit();
        console.log(`⚡ [Worker Device ${deviceId}] Break finished! Next batch rolled: ${state.currentBatchLimit} leads.`);
      } else {
        // Random 1 to 2 minutes jitter between messages
        const jitterDelayMs = getRandomMsgDelayMs();
        const delaySec = Math.round(jitterDelayMs / 1000);
        state.nextActionTime = Date.now() + jitterDelayMs;
        state.currentStatus = `Waiting ${delaySec}s before next lead (1-2m jitter)...`;
        console.log(`⏳ [Pacing Device ${deviceId}] Next lead scheduled at ${formatLocalTime(state.nextActionTime)} (${delaySec}s delay)...`);
        await sleep(jitterDelayMs);
      }
    } else {
      await sleep(2000);
    }
  }
}

/**
 * Start queue workers across all devices
 */
async function startQueueWorker() {
  if (isRunning) return;
  isRunning = true;
  console.log(`🚀 [Multi-Device Master Engine Active] Up to ${MAX_DEVICES} devices, ${getDailyMaxLeadsPerDevice()} leads/day each (3 devices = 150 leads/day, 6 devices = 300/day).`);

  for (let i = 1; i <= MAX_DEVICES; i++) {
    getOrCreateDeviceState(i);
    runDeviceWorker(i).catch(err => {
      console.error(`Worker error on device ${i}:`, err.message);
    });
  }
}

function pauseQueue() {
  isPaused = true;
  console.log('⏸️ [Queue Worker] Paused all devices');
}

function resumeQueue() {
  isPaused = false;
  console.log('▶️ [Queue Worker] Resumed all devices');
}

function getQueueState() {
  const db = scraper.loadDatabase();
  const queuedCount = db.leads.filter(l => l.status === 'queued').length;
  const sentCount = db.leads.filter(l => l.status === 'sent').length;
  checkAndResetDailyCounters();

  const connectedDevices = whatsapp.getConnectedDevices();
  const currentLimit = getDailyMaxLeadsPerDevice();
  let totalDailySent = 0;
  let totalSessionSent = 0;

  const devicesDetail = [];
  const now = Date.now();

  for (let i = 1; i <= MAX_DEVICES; i++) {
    const s = getOrCreateDeviceState(i);
    const dev = whatsapp.getDevice(i);
    const devLimit = getDailyLimitForDevice(i);
    const remainingSec = s.nextActionTime ? Math.max(0, Math.round((s.nextActionTime - now) / 1000)) : 0;
    const isSpecial10 = devLimit === 10 || (dev && dev.phone && String(dev.phone).includes('9416085989'));

    totalDailySent += s.dailySentCount;
    totalSessionSent += s.totalSentSession;

    devicesDetail.push({
      id: i,
      isConnected: dev ? dev.isConnected : false,
      phone: dev ? dev.phone : null,
      isSpecial10: isSpecial10,
      dailySentCount: s.dailySentCount,
      dailyMaxLeads: devLimit,
      currentBatchCount: s.currentBatchCount,
      batchSize: s.currentBatchLimit,
      currentStatus: s.currentStatus,
      nextActionTime: formatLocalTime(s.nextActionTime),
      nextActionTimestamp: s.nextActionTime,
      nextActionRemainingSec: remainingSec
    });
  }

  const activeCount = connectedDevices.length;
  const dynamicTarget = activeCount > 0 ? activeCount * currentLimit : currentLimit * MAX_DEVICES;

  return {
    isRunning,
    isPaused,
    maxDevices: MAX_DEVICES,
    connectedDevicesCount: activeCount,
    dailySentCount: totalDailySent,
    dailyMaxLeads: dynamicTarget,
    dailyMaxPerDevice: currentLimit,
    botConfig: getBotConfig(),
    totalSentSession: totalSessionSent,
    totalSentDb: sentCount,
    queuedRemaining: queuedCount,
    isDaytime: isOperatingHours(),
    devices: devicesDetail,
    // Backwards compatibility shortcuts
    currentStatus: activeCount > 0 ? `${activeCount}/${MAX_DEVICES} Devices Active (${totalDailySent}/${dynamicTarget} Sent)` : 'Waiting for WhatsApp QR scan on /qr...',
    batchSize: 7,
    currentBatchCount: 0,
    nextActionTime: null
  };
}

module.exports = {
  startQueueWorker,
  pauseQueue,
  resumeQueue,
  getQueueState,
  getDailyMaxLeadsPerDevice,
  setDailyMaxLeadsPerDevice,
  getBotConfig
};
