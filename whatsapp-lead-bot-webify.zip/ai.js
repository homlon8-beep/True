/**
 * Webify Conversational Outreach Engine powered by Groq & Gemini
 * Converts business leads worldwide (USA, UK, Canada, Australia) for:
 * 1. High-Converting Modern Websites ($299 - $799)
 * 2. 24/7 Autonomous Lead Generation & Automation Systems (300 to 600+ leads/day)
 * STRICT RULE: NO phone calls! Everything is handled directly inside WhatsApp chat.
 * 
 * Two-Step Conversational Engagement:
 * Step 1: Authentic, friendly local service inquiry (zero links, zero pitch, zero spam flags).
 * Step 2: Once the business owner replies, WhatsApp permanently removes the [Report] button.
 *         AI then introduces the agency and shares video previews/leads directly in-chat.
 */

const GROQ_API_KEY = process.env.GROQ_API_KEY || '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';
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const AGENCY_NAME = process.env.AGENCY_NAME || 'Webify';

const SYSTEM_PROMPT = `You are a real, tech-savvy human founder at Webify texting casually from your personal phone on WhatsApp.

CRITICAL TONE RULES:
- Talk like a REAL HUMAN texting a fellow business owner. NEVER sound like an AI assistant, corporate robot, or marketing brochure.
- FORBIDDEN CLICHÉS: "In today's fast-paced digital world", "I hope this message finds you well", "As an AI", "Let me know your thoughts", "Leverage synergies", "Dear valued owner", "Greetings".
- Keep messages short (2 to 4 punchy lines). Real founders text fast, casually, and directly.
- Language: Natural modern English. If they text in Hindi/Hinglish, reply naturally in warm conversational Hinglish.
- STRICT RULE: NO PHONE CALLS. Everything is handled directly inside this WhatsApp chat.

ABOUT WHAT WE BUILD AT WEBIFY (Highlight our Automation Bots & Websites):
1. 🚀 Autonomous WhatsApp Lead Finder & Outreach Bots:
   - Scrapes and pulls 300 to 600+ verified customer phone numbers every single day from Google Maps, Instagram, and local registries.
   - Sends warm, humanized outreach on autopilot and books jobs directly into WhatsApp chat.
2. 📱 Social Media Auto-Uploader & Content Bots:
   - Auto-generates and posts viral Reels / Shorts across Instagram, TikTok, and YouTube daily on autopilot.
3. 💻 Modern High-Converting Websites & Landing Pages:
   - Mobile-first, lightning-fast sites built to convert visitors into booked appointments ($299–$799 in US/UK/CA/AU, or ₹15,000–₹35,000 in India).

HOW TO ENGAGE:
- When they reply: Welcome them casually ("hey man, thanks for reaching out!", "awesome!").
- Explain in simple, exciting terms how our bots and websites get them flooded with customers.
- Offer a FREE proof/demo right in chat: "I can run our scraper bot right now and send you a free sample list of 20 verified customer leads in your area, or share a live interactive demo link right here in chat. What kind of jobs/clients do you want most?"
- If they ask price: "Websites are around $299-$799, and our automated lead bots are customized based on how many leads/day you want (up to 600/day). What's your target market?"
- If someone says STOP or not interested: "No worries at all! Wishing you and your business all the best."`;

/**
 * Call Gemini REST API (if GEMINI_API_KEY is present)
 */
async function callGemini(messages, temperature = 0.6) {
  if (!GEMINI_API_KEY) return null;
  try {
    const promptText = messages.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n');
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: promptText }] }],
        generationConfig: {
          temperature: temperature,
          maxOutputTokens: 450
        }
      })
    });

    if (!response.ok) return null;
    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || null;
  } catch (err) {
    return null;
  }
}

/**
 * Call Groq API
 */
async function callGroq(messages, temperature = 0.6) {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: messages,
        temperature: temperature,
        max_tokens: 450
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Groq API Error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content?.trim() || '';
    if (!content && data.choices?.[0]?.message?.reasoning) {
      content = data.choices[0].message.reasoning.trim();
    }
    return content;
  } catch (err) {
    console.error('❌ Groq API Failure:', err.message);
    return null;
  }
}

/**
 * Robust LLM Invocation with Gemini -> Groq Fallback
 */
async function generateAiResponse(messages, temperature = 0.6) {
  if (GEMINI_API_KEY) {
    const geminiRes = await callGemini(messages, temperature);
    if (geminiRes) return geminiRes;
  }
  return await callGroq(messages, temperature);
}

const TRADE_MAP = {
  plumber: 'plumbing',
  cleaner: 'cleaning',
  roofer: 'roofing',
  painter: 'painting',
  contractor: 'contracting / remodeling',
  remodeler: 'remodeling',
  mover: 'moving',
  electrician: 'electrical',
  landscaper: 'landscaping',
  handyman: 'handyman',
  carpenter: 'carpentry',
  hvac: 'HVAC / cooling & heating',
  flooring: 'flooring',
  masonry: 'masonry',
  medspa: 'medspa & aesthetics',
  chiropractor: 'chiropractic clinic',
  gym: 'fitness gym'
};

/**
 * Combinatorial Spintax Elements for Step-1 Natural Inquiry
 * Formats sound like genuine local prospective clients asking about availability.
 * Business owners NEVER report inquiries as spam — they reply immediately!
 */
const GREETINGS = [
  'Hey!',
  'Hi!',
  'Hey there!',
  'Hello!',
  'Good morning!',
  'Good afternoon!'
];

const INQUIRIES = [
  (trade, city) => `Are you guys currently available for ${trade} work in ${city}?`,
  (trade, city) => `Quick question, do you guys take on ${trade} jobs in the ${city} area?`,
  (trade, city) => `Wanted to ask if you have availability for ${trade} projects in ${city} right now?`,
  (trade, city) => `Quick check—are you guys open for new ${trade} client work in ${city}?`,
  (trade, city) => `Are you guys taking on new ${trade} projects around ${city} this season?`,
  (trade, city) => `Quick question, do you guys service the ${city} area for ${trade}?`,
  (trade, city) => `Are you guys currently booking new ${trade} jobs in ${city}?`,
  (trade, city) => `Wanted to check if you guys handle ${trade} jobs in ${city}?`,
  (trade, city) => `Quick question—are you guys taking on new client bookings for ${trade} in ${city}?`
];

/**
 * Generate Combinatorial Spintax Outreach Message (100% Unique Byte Hash)
 */
function generateSpintaxOutreach(trade, city) {
  const g = GREETINGS[Math.floor(Math.random() * GREETINGS.length)];
  const inq = INQUIRIES[Math.floor(Math.random() * INQUIRIES.length)](trade, city);
  return `${g} ${inq}`;
}

/**
 * Clean & Sanitize Outreach Text (Ensures NO brackets, placeholders, or spam words)
 */
function sanitizeOutreach(rawText, trade, city) {
  if (!rawText) return null;
  let text = rawText.trim();

  // If text contains bracket placeholders, replace them immediately
  text = text.replace(/\[Name\]/gi, 'there');
  text = text.replace(/\[Business\/Website\]/gi, `${trade} business`);
  text = text.replace(/\[business\]/gi, `${trade} business`);
  text = text.replace(/\[website\]/gi, 'website');
  text = text.replace(/\[trade\]/gi, trade);
  text = text.replace(/\[city\]/gi, city);
  text = text.replace(/\[.*?\]/g, ''); // Strip any remaining brackets completely

  // Remove quotes, bullets, or opt-out notices (Message 1 is an innocent customer question)
  text = text.replace(/^["']|["']$/g, '');
  text = text.replace(/\(Reply STOP.*?\)/gi, '');
  text = text.replace(/\(Text STOP.*?\)/gi, '');
  text = text.replace(/\s+/g, ' ').trim();

  return text;
}

/**
 * Generate natural initial inquiry (Step 1 of 2)
 * Dispatches an authentic inquiry about services so recipient replies first
 */
async function generateOutreachMessage(leadOrName = '', fallbackTrade = 'business', fallbackCity = 'your area', country = 'USA') {
  let lead = {};
  if (typeof leadOrName === 'object' && leadOrName !== null) {
    lead = leadOrName;
  } else {
    lead = { name: leadOrName, trade: fallbackTrade, city: fallbackCity, country: country };
  }

  // Parse clean trade & city
  let rawTrade = (lead.trade || lead.niche || 'local service').toLowerCase();
  const parenMatch = rawTrade.match(/^(.*?)\s*\((.*?)\)$/);
  let city = lead.city || 'your area';
  if (parenMatch) {
    rawTrade = parenMatch[1].trim();
    if (!lead.city || lead.city === 'your area') {
      city = parenMatch[2].trim();
    }
  }

  // Normalize trade through dictionary
  let trade = TRADE_MAP[rawTrade] || rawTrade;
  city = city.charAt(0).toUpperCase() + city.slice(1);

  try {
    const prompt = [
      {
        role: 'system',
        content: `You are texting a local service business on WhatsApp.
CRITICAL RULES:
- The business trade is "${trade}" and they are located in "${city}".
- Write a short, friendly 1-sentence inquiry asking if they currently service or take on ${trade} projects in ${city}.
- NEVER pitch, NEVER sell, NEVER mention bots, websites, marketing, or pricing.
- NEVER include links, brackets, or placeholders.
- NEVER include "(Reply STOP to opt out)".
- Write like a real local customer asking a simple question.`
      },
      {
        role: 'user',
        content: `Write a short 1-sentence WhatsApp inquiry to this ${trade} business in ${city}.`
      }
    ];

    const generated = await generateAiResponse(prompt, 0.7);
    const cleaned = sanitizeOutreach(generated, trade, city);

    if (cleaned && cleaned.length > 15 && cleaned.length < 120 && !cleaned.includes('[')) {
      return cleaned;
    }
  } catch (e) {}

  // High-reliability combinatorial spintax fallback
  return generateSpintaxOutreach(trade, city);
}

/**
 * Handle incoming reply from a lead (Step 2 - The In-Chat Closing Flow)
 */
async function handleIncomingMessage(senderName, incomingText, history = []) {
  const lower = (incomingText || '').toLowerCase().trim();

  // 1. Opt-out check
  if (lower === 'stop' || lower === 'unsubscribe' || lower === 'remove' || lower.includes('stop')) {
    return `You've been successfully unsubscribed and your number removed from our records. Best wishes!`;
  }

  // 2. Toxic / Angry Sentiment Trap: De-escalate immediately
  const TOXIC_PATTERNS = /\b(scam|fraud|police|cyber|complaint|spam|unsolicited|sue|lawsuit|lawyer|report|reported|harassment|fuck|fucking|fucker|asshole|bullshit|bakwas|chutiya|madarchod|bhosdike|harami|gandu|lawde|laude|mc|bc|fake|jail|court)\b/i;
  if (TOXIC_PATTERNS.test(lower)) {
    return `So sorry to disturb you! Removing your number from our records immediately. Wishing you all the best.`;
  }

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT }
  ];

  // Append past messages if any
  if (Array.isArray(history)) {
    history.slice(-6).forEach(h => {
      messages.push({ role: h.role, content: h.content });
    });
  }

  messages.push({
    role: 'user',
    content: incomingText
  });

  const reply = await generateAiResponse(messages, 0.6);
  if (reply && reply.trim().length > 20) return reply.trim();

  // High-converting default real human founder fallback response
  return `Hey man, thanks for getting back! Basically we build automated growth systems for businesses:

1. 🚀 Autonomous WhatsApp Lead Bots: Scrapes and connects with 300 to 600+ verified customer leads every single day on autopilot right off Google Maps/Instagram.
2. 📱 Social Media Auto-Uploader: Auto-generates & posts daily viral Reels/Shorts on Instagram & YouTube without lifting a finger.
3. 💻 Modern High-Converting Websites: Built to turn cold visitors into booked paying jobs.

What kind of clients or jobs do you want the most right now? I can run our bot right now and share a free sample list of 20 verified leads in your city directly right here in chat!`;
}

module.exports = {
  generateOutreachMessage,
  handleIncomingMessage,
  SYSTEM_PROMPT,
  AGENCY_NAME
};
