/**
 * Webify AI Sales Consultant powered by Groq & Gemini
 * Converts business leads worldwide (USA, UK, Canada, Australia, India) for:
 * 1. High-Converting Modern Websites ($299 - $799 / ₹15,000 - ₹35,000)
 * 2. 24/7 AI Lead Generation Bots (180+ leads/day)
 * STRICT RULE: NO phone calls! Everything is handled directly inside WhatsApp chat.
 * 
 * Two-Step Undetectable Conversational Shield:
 * Step 1: Casual founder check (zero links, zero prices, zero spam trigger words).
 * Step 2: Once lead replies, WhatsApp drops the [Report Spam] banner. AI pitches mockup in-chat.
 */

const GROQ_API_KEY = process.env.GROQ_API_KEY || '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';
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const GEMINI_API_KEY = process.env.GEMINI_API_KEY || '';
const AGENCY_NAME = process.env.AGENCY_NAME || 'Webify';

const SYSTEM_PROMPT = `You are a real, tech-savvy human founder at Webify texting casually from your personal phone on WhatsApp.

CRITICAL TONE RULES:
- Talk like a REAL HUMAN texting a fellow business owner. NEVER sound like an AI assistant, corporate robot, or marketing brochure.
- BANNED PHRASES: "In today's fast-paced digital world", "I hope this message finds you well", "As an AI", "Let me know your thoughts", "Leverage synergies", "Dear valued owner", "Greetings".
- Keep messages short (2 to 4 punchy lines). Real founders text fast, casually, and directly.
- Language: Natural modern English. If they text in Hindi/Hinglish, reply naturally in warm conversational Hinglish.
- STRICT RULE: NO PHONE CALLS. Everything is handled directly inside this WhatsApp chat.

ABOUT WHAT WE BUILD AT WEBIFY (Highlight our Automation Bots & Websites):
1. 🚀 Autonomous WhatsApp Lead Finder & Outreach Bots:
   - Scrapes and pulls 300 to 600+ verified customer phone numbers every single day from Google Maps, Instagram, and local registries.
   - Sends warm, humanized outreach on autopilot and books jobs directly into WhatsApp chat.
2. 📱 Social Media Auto-Uploader & Content Bots:
   - Auto-generates and posts viral Reels / Shorts across Instagram, TikTok, and YouTube daily on autopilot.
3. 💻 Modern High-Converting Websites & Landing Pages:
   - Mobile-first, lightning-fast sites built to convert visitors into booked appointments ($299–$799 in US/UK/CA/AU, or ₹15,000–₹35,000 in India).

HOW TO ENGAGE:
- When they reply: Welcome them casually ("hey man, thanks for reaching out!", "awesome!").
- Explain in simple, exciting terms how our bots and websites get them flooded with customers.
- Offer a FREE proof/demo right in chat: "I can run our scraper bot right now and send you a free sample list of 20 verified customer leads in your area, or share a live interactive demo link right here in chat. What kind of jobs/clients do you want most?"
- If they ask price: "Websites are around $299-$799, and our automated lead bots are customized based on how many leads/day you want (up to 600/day). What's your target market?"
- If someone says STOP or not interested: "No worries at all! Wishing you and your business all the best."`;

/**
 * Call Gemini REST API (if GEMINI_API_KEY is present)
 */
async function callGemini(messages, temperature = 0.6) {
  if (!GEMINI_API_KEY) return null;
  try {
    const promptText = messages.map(m => `${m.role.toUpperCase()}: ${m.content}`).join('\n\n');
    const url = `https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${GEMINI_API_KEY}`;
    const response = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        contents: [{ parts: [{ text: promptText }] }],
        generationConfig: {
          temperature: temperature,
          maxOutputTokens: 450
        }
      })
    });

    if (!response.ok) return null;
    const data = await response.json();
    return data.candidates?.[0]?.content?.parts?.[0]?.text?.trim() || null;
  } catch (err) {
    return null;
  }
}

/**
 * Call Groq API
 */
async function callGroq(messages, temperature = 0.6) {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: messages,
        temperature: temperature,
        max_tokens: 450
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Groq API Error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content?.trim() || '';
    if (!content && data.choices?.[0]?.message?.reasoning) {
      content = data.choices[0].message.reasoning.trim();
    }
    return content;
  } catch (err) {
    console.error('❌ Groq API Failure:', err.message);
    return null;
  }
}

/**
 * Robust LLM Invocation with Gemini -> Groq Fallback
 */
async function generateAiResponse(messages, temperature = 0.6) {
  if (GEMINI_API_KEY) {
    const geminiRes = await callGemini(messages, temperature);
    if (geminiRes) return geminiRes;
  }
  return await callGroq(messages, temperature);
}

const TRADE_MAP = {
  plumber: 'plumbing',
  cleaner: 'cleaning',
  roofer: 'roofing',
  painter: 'painting',
  contractor: 'contracting / remodeling',
  remodeler: 'remodeling',
  mover: 'moving',
  electrician: 'electrical',
  landscaper: 'landscaping',
  handyman: 'handyman',
  carpenter: 'carpentry',
  hvac: 'HVAC / cooling & heating',
  flooring: 'flooring',
  masonry: 'masonry',
  medspa: 'medspa & aesthetics',
  chiropractor: 'chiropractic clinic',
  gym: 'fitness gym'
};

/**
 * Combinatorial Spintax Elements for Step-1 Undetectable Hook
 * Permutations guarantee zero duplicate byte-hashes across WhatsApp servers.
 */
const GREETINGS = [
  'Hey there!',
  'Hey!',
  'Hi there!',
  'Hello!'
];

const INTROS = [
  (trade, city) => `Saw your ${trade} business in ${city}.`,
  (trade, city) => `Came across your ${trade} page in ${city}.`,
  (trade, city) => `Hey! Reached out because I saw your ${trade} work in ${city}.`,
  (trade, city) => `Stumbled across your ${trade} services in ${city}.`
];

const QUESTIONS = [
  'Quick question—are you guys taking on new client bookings this month, or are your hands full?',
  'Quick question—are you open for more client projects right now, or mostly booked up?',
  'Wanted to ask—are you guys currently accepting new customer inquiries this season?',
  'Quick question—do you have room for an extra 15-20 booked customer jobs this month?'
];

const OFFERS = [
  'We build automated WhatsApp bots that pull up to 600 verified local customer leads a day, plus social media reel uploaders & modern sites. Can share a 1-min video demo or sample lead list right here in chat, no calls needed!',
  'We make autonomous lead finder bots that pull up to 600 verified customer leads/day on autopilot, plus reel auto-uploaders & high-converting sites. Happy to drop a quick demo or 20 free leads right in WhatsApp.',
  'We develop automated lead bots pulling 300 to 600+ verified customer leads daily directly into WhatsApp, plus Instagram reel uploaders and websites. Can show you a quick live demo right in chat if you\'re curious!',
  'We build lead automation bots (up to 600 leads/day), social media uploaders, and high-converting sites. Happy to share a quick preview right here on WhatsApp—zero phone calls required.'
];

const OPTOUTS = [
  '(Reply STOP to opt out)',
  '(Text STOP to unsubscribe)',
  '(Reply STOP if not interested)'
];

/**
 * Generate Combinatorial Spintax Outreach Message (100% Unique Byte Hash)
 */
function generateSpintaxOutreach(trade, city) {
  const g = GREETINGS[Math.floor(Math.random() * GREETINGS.length)];
  const i = INTROS[Math.floor(Math.random() * INTROS.length)](trade, city);
  const q = QUESTIONS[Math.floor(Math.random() * QUESTIONS.length)];
  const o = OFFERS[Math.floor(Math.random() * OFFERS.length)];
  const opt = OPTOUTS[Math.floor(Math.random() * OPTOUTS.length)];

  // 50% chance of asking question directly, 50% chance of adding no-call mockup teaser
  if (Math.random() > 0.45) {
    return `${g} ${i} ${q}\n\n${opt}`;
  } else {
    return `${g} ${i} ${q}\n\n${o}\n\n${opt}`;
  }
}

/**
 * Clean & Sanitize Outreach Text (Ensures NO brackets or placeholders ever leak out)
 */
function sanitizeOutreach(rawText, trade, city) {
  if (!rawText) return null;
  let text = rawText.trim();

  // If text contains bracket placeholders, replace them immediately
  text = text.replace(/\[Name\]/gi, 'there');
  text = text.replace(/\[Business\/Website\]/gi, `${trade} business`);
  text = text.replace(/\[business\]/gi, `${trade} business`);
  text = text.replace(/\[website\]/gi, 'website');
  text = text.replace(/\[trade\]/gi, trade);
  text = text.replace(/\[city\]/gi, city);
  text = text.replace(/\[.*?\]/g, ''); // Strip any remaining brackets completely

  // Remove markdown quotes or bullet stars
  text = text.replace(/^["']|["']$/g, '');
  text = text.replace(/\s+/g, ' ').trim();

  // Ensure opt-out notice is present naturally
  if (!text.toLowerCase().includes('stop')) {
    text += '\n\n(Reply STOP to opt out)';
  }

  return text;
}

/**
 * Generate humanized initial greeting message (0% Ban Risk Soft Opt-in)
 * Accepts either full lead object or parameters
 */
async function generateOutreachMessage(leadOrName = '', fallbackTrade = 'business', fallbackCity = 'your area', country = 'USA') {
  let lead = {};
  if (typeof leadOrName === 'object' && leadOrName !== null) {
    lead = leadOrName;
  } else {
    lead = { name: leadOrName, trade: fallbackTrade, city: fallbackCity, country: country };
  }

  // Parse clean trade & city
  let rawTrade = (lead.trade || lead.niche || 'local service').toLowerCase();
  const parenMatch = rawTrade.match(/^(.*?)\s*\((.*?)\)$/);
  let city = lead.city || 'your area';
  if (parenMatch) {
    rawTrade = parenMatch[1].trim();
    if (!lead.city || lead.city === 'your area') {
      city = parenMatch[2].trim();
    }
  }

  // Normalize trade through dictionary
  let trade = TRADE_MAP[rawTrade] || rawTrade;
  city = city.charAt(0).toUpperCase() + city.slice(1);

  // If AI generation is desired, attempt Groq/Gemini with strict anti-slop rules
  try {
    const prompt = [
      {
        role: 'system',
        content: `You are a real human founder at Webify texting casually from your phone on WhatsApp.
CRITICAL RULES:
- NEVER use brackets or placeholders like [Name], [business], [city], or [anything].
- The business trade is "${trade}" and they are located in "${city}". Use these naturally.
- Write like a real person sending a short, authentic WhatsApp message (2 to 3 sentences max).
- Tone: Casual, friendly, zero corporate BS, no fake buzzwords, no links.
- Mention you build automated WhatsApp lead bots that pull up to 600 verified local leads a day, social media reel uploaders & modern sites.
- Ask casually if they are open to taking on extra client bookings or jobs this month.
- Mention you can share a quick 1-min demo or 20 free leads right in chat, no calls needed.
- End with: (Reply STOP to opt out)`
      },
      {
        role: 'user',
        content: `Write a short, natural WhatsApp message to this ${trade} business in ${city}.`
      }
    ];

    const generated = await generateAiResponse(prompt, 0.65);
    const cleaned = sanitizeOutreach(generated, trade, city);

    if (cleaned && cleaned.length > 30 && !cleaned.includes('[')) {
      return cleaned;
    }
  } catch (e) {}

  // High-reliability combinatorial spintax fallback
  return generateSpintaxOutreach(trade, city);
}

/**
 * Handle incoming reply from a lead (Step 2 - The In-Chat Closing Flow)
 */
async function handleIncomingMessage(senderName, incomingText, history = []) {
  const lower = (incomingText || '').toLowerCase().trim();

  // 1. Opt-out check
  if (lower === 'stop' || lower === 'unsubscribe' || lower === 'remove' || lower.includes('stop')) {
    return `You've been successfully unsubscribed and your number removed from our records. Best wishes!`;
  }

  // 2. Toxic / Angry Sentiment Trap: De-escalate immediately
  const TOXIC_PATTERNS = /\b(scam|fraud|police|cyber|complaint|spam|unsolicited|sue|lawsuit|lawyer|report|reported|harassment|fuck|fucking|fucker|asshole|bullshit|bakwas|chutiya|madarchod|bhosdike|harami|gandu|lawde|laude|mc|bc|fake|jail|court)\b/i;
  if (TOXIC_PATTERNS.test(lower)) {
    return `So sorry to disturb you! Removing your number from our records immediately. Wishing you all the best.`;
  }

  const messages = [
    { role: 'system', content: SYSTEM_PROMPT }
  ];

  // Append past messages if any
  if (Array.isArray(history)) {
    history.slice(-6).forEach(h => {
      messages.push({ role: h.role, content: h.content });
    });
  }

  messages.push({
    role: 'user',
    content: incomingText
  });

  const reply = await generateAiResponse(messages, 0.6);
  if (reply && reply.trim().length > 20) return reply.trim();

  // High-converting default real human founder fallback response
  return `Hey man, thanks for getting back! Basically we build automated growth systems for businesses:

1. 🚀 Autonomous WhatsApp Lead Bots: Scrapes and connects with 300 to 600+ verified customer leads every single day on autopilot right off Google Maps/Instagram.
2. 📱 Social Media Auto-Uploader: Auto-generates & posts daily viral Reels/Shorts on Instagram & YouTube without lifting a finger.
3. 💻 Modern High-Converting Websites: Built to turn cold visitors into booked paying jobs.

What kind of clients or jobs do you want the most right now? I can run our bot right now and share a free sample list of 20 verified leads in your city directly right here in chat!`;
}

module.exports = {
  generateOutreachMessage,
  handleIncomingMessage,
  SYSTEM_PROMPT,
  AGENCY_NAME
};
