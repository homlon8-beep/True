/**
 * Bemisaal Wellness - Ayurvedic & Unani Health Outreach Consultant
 * Official Health Consultation Team: Bemisaal Wellness
 * Helpline: 9990394794
 * Pure 100% Indian (+91) Health Outreach & Dignified Hinglish Consultation
 */

const GROQ_API_KEY = process.env.GROQ_API_KEY || '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';
const GROQ_MODEL = process.env.GROQ_MODEL || 'openai/gpt-oss-120b';
const BRAND_NAME = process.env.BRAND_NAME || 'Bemisaal Wellness';
const HELPLINE = process.env.HELPLINE_NUMBER || '9990394794';

const SYSTEM_PROMPT = `Aap Bemisaal Wellness ki Senior Ayurvedic & Unani Health Consultant team hain.
Aap bohot shaant, respectful, knowledgeable aur empathetic hain.

Halaat:
User ne online search par mardana kamzori, timing ki samasya, shighrapatan, naso ki kamzori ya herbal ilaj ke bare me poocha tha.
Aapka lakshya: Unki samasya ko bina kisi sharam ke samajhna, unhe bharosa dilana, aur hamare 100% natural Unani Shahi Majoon + Tila Oil + Tablets 30-Day Course ke bare me samjhana.

Sharik Shah Official Treatment Blueprint:
1. 2 Shahi Majoon – virya aur timing ke liye.
2. 1 Tila Oil – naso ki takat aur blood circulation ke liye.
3. 30 Tablet pack – stamina boost.
4. 0% Steroids, 0% Chemicals. 100% Shuddh Unani Nuskha.
5. Payment Policy: Hum order booking ke liye ₹200 advance online lete hain aur baki remaining payment delivery ke waqt COD (Cash on Delivery) par deni hoti hai.
6. All India 100% discreet confidential packaging.
7. Helpline: ${HELPLINE}

Expert Objection Handling Guidelines:
- Agar patient puche "₹200 advance kyun de? Pura COD karo":
  Samjhao ki: "Bhai, all India courier booking aur confidential dispatch verify karne ke liye company rule mutabiq ₹200 booking charge lagta hai, baki pure paise aap parcel haath me lene ke baad hi cash dete hain."
- Agar patient puche "Koi side effect toh nahi hai?":
  Samjhao ki: "Yeh 100% certified Ayurvedic aur Unani jari bootiyon se banta hai, zero chemicals aur zero steroids. Koi bhi side effect nahi hota."
- Agar patient puche "Kitne din me asar dikhega?":
  Samjhao ki: "Pehle 7-10 din me naso me takat aur energy me fark aana shuru ho jata hai, aur pura 30-day course lene par permanent result milta hai."
- Agar patient puche "Packaging kaisi hogi, ghar wale na dekh le":
  Samjhao ki: "Packing 100% discreet aur plain hoti hai. Bahar box par kisi tarah ka product name ya bimari ka zikr nahi hota, bilkul private rehta hai."
- Bhasha: Natural, respectful, simple Hinglish (jaise WhatsApp par ek doctor patient se baat karta hai).
- Kabhi bhi ashlil ya vulgar shabd mat use karna. Clean, dignified medical tone rakhna.`;

/**
 * Call Groq API
 */
async function callGroq(messages, temperature = 0.6) {
  try {
    const response = await fetch('https://api.groq.com/openai/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${GROQ_API_KEY}`,
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        model: GROQ_MODEL,
        messages: messages,
        temperature: temperature,
        max_tokens: 350
      })
    });

    if (!response.ok) {
      const errText = await response.text();
      throw new Error(`Groq API Error (${response.status}): ${errText}`);
    }

    const data = await response.json();
    let content = data.choices?.[0]?.message?.content?.trim() || '';
    if (!content && data.choices?.[0]?.message?.reasoning) {
      content = data.choices[0].message.reasoning.trim();
    }
    return content;
  } catch (err) {
    console.error('❌ Groq API Failure:', err.message);
    return null;
  }
}

/**
 * Dynamic Time-Of-Day Salutation (IST Clinic Hours Context)
 */
function getTimeBasedSalutation() {
  const now = new Date();
  const istStr = now.toLocaleString('en-US', { timeZone: 'Asia/Kolkata' });
  const hour = new Date(istStr).getHours();
  if (hour >= 9 && hour < 12) return ['Shubh prabhat', 'Namaste', 'Good morning'][Math.floor(Math.random() * 3)];
  if (hour >= 12 && hour < 17) return ['Shubh dopahar', 'Namaste', 'Namaskar'][Math.floor(Math.random() * 3)];
  return ['Shubh sandhya', 'Namaste', 'Namaskar'][Math.floor(Math.random() * 3)];
}

const DESK_NAMES = [
  'Bemisaal Wellness health desk',
  'Bemisaal Wellness clinic care team',
  'Bemisaal Ayurvedic & Unani healthcare desk',
  'Bemisaal Wellness patient support desk'
];

const INQUIRY_CONTEXTS = [
  'Aapki Ayurvedic health guidance ke regarding inquiry mili thi.',
  'Aapka wellness consultation inquiry form receive hua tha.',
  'Aapne jo herbal wellness consultation request submit ki thi uske regarding message tha.',
  'Aapki wellness care consultation request system me register hui thi.'
];

const HOOKS = [
  'Kya abhi 2 minute baat ho sakti hai?',
  'Confirm karna tha details yahan WhatsApp par share karein ya direct doctor call schedule karein?',
  'Kya abhi aap 2 minute free hain consultation ke baare me discuss karne ke liye?',
  'Kya abhi details WhatsApp par provide karein ya phone call arrange karein?'
];

/**
 * Generate Initial Outreach Message with Deep Combinatorial Spintax (Zero Byte Hash Duplication)
 */
async function generateOutreachMessage(leadOrName = '') {
  let leadName = '';
  if (typeof leadOrName === 'object' && leadOrName !== null) {
    leadName = leadOrName.name || '';
  } else {
    leadName = leadOrName || '';
  }

  leadName = leadName.replace(/[^\w\s]/g, '').trim().slice(0, 20);

  const salutation = getTimeBasedSalutation();
  const greeting = leadName 
    ? (Math.random() > 0.5 ? `${salutation} ${leadName} ji` : `${salutation} ${leadName} bhai`)
    : `${salutation} ji`;

  const desk = DESK_NAMES[Math.floor(Math.random() * DESK_NAMES.length)];
  const context = INQUIRY_CONTEXTS[Math.floor(Math.random() * INQUIRY_CONTEXTS.length)];
  const hook = HOOKS[Math.floor(Math.random() * HOOKS.length)];

  return `${greeting}, ${desk} se message tha.\n\n${context} ${hook}\n\n(Reply STOP to opt out)`;
}

/**
 * Handle incoming reply from a lead/patient (Sharik Shah Official Response)
 */
async function handleIncomingMessage(senderName, incomingText, history = []) {
  const prompt = [
    { role: 'system', content: SYSTEM_PROMPT }
  ];

  if (Array.isArray(history)) {
    history.slice(-6).forEach(h => {
      prompt.push({ role: h.role, content: h.content });
    });
  }

  prompt.push({
    role: 'user',
    content: incomingText
  });

  const reply = await callGroq(prompt, 0.6);
  if (reply && reply.trim().length > 30) return reply.trim();

  // Sharik Shah exact official response
  return `Namaste, mujhe aapki pareshani samajh aa rahi hai aur aapko behtar health dene ke liye humara 30-din ka Unani Shahi Majoon + Tila Oil + Daily Recovery Tablets bilkul natural, steroid-free solution hai.\n\n✅ 2 Shahi Majoon – virya aur timing ke liye\n✅ Tila Oil – naso ki takat aur blood circulation ke liye\n✅ 30 Tablet pack – stamina boost\n\n📦 Order & Payment: Hum delivery booking ke liye ₹200 advance online lete hain aur baki remaining payment parcel milne par Cash on Delivery (COD) par dena hota hai. All India discreet packaging.\n\nDetailed guidance ke liye aap humari medical team se call ya WhatsApp kar sakte hain: ${HELPLINE}\n\n💡 Note: Aap yeh helpline number save kar sakte hain taaki future guidance aur order updates ke liye direct contact bana rahe.`;
}

module.exports = {
  generateOutreachMessage,
  handleIncomingMessage,
  SYSTEM_PROMPT,
  HELPLINE
};
